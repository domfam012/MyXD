module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 12);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/Od0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _public_js_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("DZwK");
/* harmony import */ var _public_js_db__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_public_js_db__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


/* harmony default export */ __webpack_exports__["default"] = (async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  res.setHeader("Access-Control-Allow-Headers", "content-type");
  res.setHeader("Content-Type", "application/json");
  const db = await Object(_public_js_db__WEBPACK_IMPORTED_MODULE_0__["loadDB"])();
  const collection = await db.collection("Posts");

  if (req.method === "GET") {
    const ref = await collection.orderBy("created", "desc").get();
    const data = [];
    ref.forEach(doc => {
      data.push(_objectSpread({
        pid: doc.id
      }, doc.data()));
    });
    const resData = JSON.stringify({
      status: 200,
      msg: "success",
      data: data
    });
    res.status(200).send(resData);
  } else {
    //
    res.json({
      status: 405,
      msg: ""
    });
  }
});

/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/Od0");


/***/ }),

/***/ "DZwK":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _app = _interopRequireDefault(__webpack_require__("wVQA"));

__webpack_require__("bnmT");

__webpack_require__("ha8t");

var _config = _interopRequireDefault(__webpack_require__("obyI"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// load firestore database
const loadDB = () => {
  try {
    _app.default.initializeApp(_config.default.option.firestore);
  } catch (err) {
    // we skip the "already exists" message which is
    // not an actual error when we're hot-reloading
    if (!/already exists/.test(err.message)) {
      console.error('Firebase initialization error', err.stack);
    }
  }

  return _app.default.firestore();
}; // laod firestore storage


const loadStorage = () => {
  try {
    _app.default.initializeApp(_config.default.option.firestore);
  } catch (err) {
    // we skip the "already exists" message which is
    // not an actual error when we're hot-reloading
    if (!/already exists/.test(err.message)) {
      console.error('Firebase initialization error', err.stack);
    }
  }

  return _app.default.storage();
};

module.exports = {
  loadDB,
  firestore: _app.default.firestore,
  loadStorage,
  storage: _app.default.storage
};

/***/ }),

/***/ "bnmT":
/***/ (function(module, exports) {

module.exports = require("firebase/firestore");

/***/ }),

/***/ "ha8t":
/***/ (function(module, exports) {

module.exports = require("firebase/storage");

/***/ }),

/***/ "obyI":
/***/ (function(module, exports) {

// live: {
//     apiKey: "AIzaSyBDq0nTd2Czqy9XtOOOdjaWEcWwdmPV_Fw",
//     authDomain: "myxd-live.firebaseapp.com",
//     databaseURL: "https://myxd-live.firebaseio.com",
//     projectId: "myxd-live",
//     storageBucket: "myxd-live.appspot.com",
//     messagingSenderId: "967461744534",
//     appId: "1:967461744534:web:89ae4ed5d1d505a9dab7b7"
// }
// stage: {
//     apiKey: "AIzaSyC_5Ia408Xj6EJ6aKbLzlOS_RHssy3R9uY",
//     authDomain: "myxd-stage.firebaseapp.com",
//     databaseURL: "https://myxd-stage.firebaseio.com",
//     projectId: "myxd-stage",
//     storageBucket: "myxd-stage.appspot.com",
//     messagingSenderId: "864151577963",
//     appId: "1:864151577963:web:185d4aaa421f8cb917982e"
// }
const option = {
  firestore: {
    apiKey: "AIzaSyDyYie0HBPkZslWwib3DNBCIXM9VBMtL3s",
    authDomain: "myxd-247f4.firebaseapp.com",
    databaseURL: "https://myxd-247f4.firebaseio.com",
    projectId: "myxd-247f4",
    storageBucket: "myxd-247f4.appspot.com",
    messagingSenderId: "575641093519",
    appId: "1:575641093519:web:56035054fbaa244dfe37fa"
  },
  assetPrefix: {
    dev: "http://localhost:3000",
    aws: "http://myxd.co.kr",
    ghp: "https://pyungwook-domfam.github.io/domfam012"
  },
  ip: {
    dev: "127.0.0.1",
    production: "13.209.55.219"
  },
  port: {
    dev: 3000,
    production: 80
  },
  GA_TRACKING_ID: "UA-158587547-1"
};
module.exports = {
  option
};

/***/ }),

/***/ "wVQA":
/***/ (function(module, exports) {

module.exports = require("firebase/app");

/***/ })

/******/ });