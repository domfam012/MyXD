module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/jkW":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
}); // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

exports.isDynamicRoute = isDynamicRoute;

/***/ }),

/***/ "0Bsm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("KI45");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router = __webpack_require__("nOHt");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return _react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (false) { var name; }

  return WithRouterWrapper;
}

/***/ }),

/***/ "0bYB":
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),

/***/ "3i/4":
/***/ (function(module, exports) {

module.exports = require("next-cookies");

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qyRQ");


/***/ }),

/***/ "5Uuq":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getOwnPropertyDescriptor = __webpack_require__("Jo+v");

var _Object$defineProperty = __webpack_require__("hfKm");

var _typeof = __webpack_require__("iZP3");

var _WeakMap = __webpack_require__("G4HQ");

function _getRequireWildcardCache() {
  if (typeof _WeakMap !== "function") return null;
  var cache = new _WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = _Object$defineProperty && _Object$getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? _Object$getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        _Object$defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "5Yp1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__("HJQg");
var style_default = /*#__PURE__*/__webpack_require__.n(style_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// EXTERNAL MODULE: external "isomorphic-unfetch"
var external_isomorphic_unfetch_ = __webpack_require__("0bYB");
var external_isomorphic_unfetch_default = /*#__PURE__*/__webpack_require__.n(external_isomorphic_unfetch_);

// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__("vmXh");
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);

// CONCATENATED MODULE: ./components/Header.js

var __jsx = external_react_default.a.createElement;




 // Header

const Header = props => {
  const router = Object(router_["useRouter"])();
  /**
   * @type {{id: string}[]}
   *
   * post list 에서 연결되어야 하며
   * id 값은 firestore 통해서 넣도록 수정
   */

  const {
    0: menuActive,
    1: setMenuState
  } = Object(external_react_["useState"])(false); //로그아웃

  const logout = async e => {
    e.preventDefault();
    const check = confirm("로그아웃 하시겠습니까?");

    if (check) {
      // console.log(`logout check true`);
      const res = await external_isomorphic_unfetch_default()(`http://myxd.co.kr/api/user/logout`);

      if (res.status === 200) {
        // console.log('logout success');
        external_js_cookie_default.a.remove('token');
        router.push('/admin/login');
      } else {
        console.log('error occured');
      }
    }
  };

  return __jsx("header", {
    className: "jsx-45394254"
  }, __jsx("div", {
    className: "jsx-45394254" + " " + "nav_wrap"
  }, __jsx("nav", {
    className: "jsx-45394254" + " " + ((props.isResponsive ? "navbar navbar-expand-xl" : "navbar navbar-expand-xl admin") || "")
  }, __jsx(link_default.a, {
    href: "/"
  }, __jsx("a", {
    className: "jsx-45394254" + " " + "navbar-brand"
  }, __jsx("span", {
    className: "jsx-45394254" + " " + "pink"
  }, __jsx("img", {
    src: "/img/common/logo.png",
    alt: "myXD",
    style: {
      width: 102 + 'px'
    },
    className: "jsx-45394254"
  })))), __jsx("button", {
    type: "button",
    "data-toggle": "collapse",
    "data-target": "#navbarText",
    "aria-controls": "navbarText",
    "aria-expanded": "false",
    "aria-label": "Toggle navigation",
    onClick: () => setMenuState(!menuActive),
    className: "jsx-45394254" + " " + `navbar-toggle ${menuActive ? 'active' : ''}`
  }, __jsx("div", {
    className: "jsx-45394254" + " " + "navbar-toggler-icon"
  }, __jsx("span", {
    className: "jsx-45394254" + " " + "bar1"
  }), __jsx("span", {
    className: "jsx-45394254" + " " + "bar2"
  }), __jsx("span", {
    className: "jsx-45394254" + " " + "bar3"
  }))), __jsx("div", {
    id: "navbarText",
    className: "jsx-45394254" + " " + "collapse navbar-collapse menu"
  }, __jsx("ul", {
    className: "jsx-45394254" + " " + "navbar-nav mr-auto"
  }, __jsx(link_default.a, {
    href: "/list?cat=uikits"
  }, __jsx("li", {
    className: "jsx-45394254" + " " + `nav-item ${props.activeMenu === 'uikits' ? 'active' : ''}`
  }, __jsx("a", {
    className: "jsx-45394254" + " " + "nav-link"
  }, "UI KITS"))), __jsx(link_default.a, {
    href: "/list?cat=website"
  }, __jsx("li", {
    className: "jsx-45394254" + " " + `nav-item ${props.activeMenu === 'website' ? 'active' : ''}`
  }, __jsx("a", {
    className: "jsx-45394254" + " " + "nav-link"
  }, "Website"))), __jsx(link_default.a, {
    href: "/list?cat=mobile"
  }, __jsx("li", {
    className: "jsx-45394254" + " " + `nav-item ${props.activeMenu === 'mobile' ? 'active' : ''}`
  }, __jsx("a", {
    className: "jsx-45394254" + " " + "nav-link"
  }, "Mobile"))), __jsx(link_default.a, {
    href: "/list?cat=plugin"
  }, __jsx("li", {
    className: "jsx-45394254" + " " + `nav-item ${props.activeMenu === 'plugin' ? 'active' : ''}`
  }, __jsx("a", {
    className: "jsx-45394254" + " " + "nav-link"
  }, "Plug-in"))))), __jsx("div", {
    className: "jsx-45394254" + " " + "collapse navbar-collapse navbar-icon"
  }, __jsx("ul", {
    className: "jsx-45394254" + " " + "navbar-nav"
  }, __jsx("li", {
    className: "jsx-45394254" + " " + "nav-item"
  }, __jsx("a", {
    href: "#",
    className: "jsx-45394254" + " " + "nav-link"
  }, __jsx("img", {
    src: "/img/common/instargram.png",
    alt: "instargram",
    className: "jsx-45394254"
  }))), __jsx("li", {
    className: "jsx-45394254" + " " + "nav-item"
  }, __jsx("a", {
    href: "#",
    className: "jsx-45394254" + " " + "nav-link"
  }, __jsx("img", {
    src: "/img/common/twitter.png",
    alt: "twitter",
    className: "jsx-45394254"
  }))), __jsx("li", {
    className: "jsx-45394254" + " " + "nav-item"
  }, __jsx("a", {
    href: "#",
    className: "jsx-45394254" + " " + "nav-link"
  }, __jsx("img", {
    src: "/img/common/facebook.png",
    alt: "facebook",
    className: "jsx-45394254"
  }))), __jsx("li", {
    className: "jsx-45394254" + " " + "nav-item"
  }, __jsx(link_default.a, {
    href: "/admin/login"
  }, __jsx("a", {
    onClick: logout,
    href: "#",
    className: "jsx-45394254" + " " + "nav-link"
  }, __jsx("img", {
    src: "/img/common/login.png",
    alt: "login",
    className: "jsx-45394254"
  })))))))), __jsx(style_default.a, {
    id: "45394254"
  }, [".nav_wrap.jsx-45394254{width:100%;background:#2e001f;height:70px;}", ".navbar.jsx-45394254{width:1200px;margin:0 auto;padding:0 30px;color:#fff;}", ".navbar-nav.jsx-45394254{width:-webkit-fit-content;width:-moz-fit-content;width:fit-content;margin:0 auto;}", ".navbar-brand.jsx-45394254{font-size:20px;line-height:66px;color:#fff;margin-right:159px;}", ".nav-link.jsx-45394254{padding:8.5px 10px !important;color:#ffffff;font-weight:bold;}", ".menu.jsx-45394254 .nav-item.active.jsx-45394254,.menu.jsx-45394254 .nav-item.jsx-45394254:hover{border-bottom:2px solid var(--pink);border-bottom:2px solid #e83e8c;color:var(--pink);color:#e83e8c;}", ".menu.jsx-45394254 .nav-item.active.jsx-45394254 .nav-link.jsx-45394254,.menu.jsx-45394254 .nav-item.jsx-45394254:hover .nav-link.jsx-45394254{color:var(--pink);color:#e83e8c;}", ".nav-item.jsx-45394254{margin-right:80px;border-color:var(--pink);border-bottom:2px solid transparent;}", ".nav-item.jsx-45394254:last-child{margin-right:0 !important;}", ".navbar-icon.jsx-45394254{position:relative;}", ".navbar-icon.jsx-45394254 .navbar-nav.jsx-45394254{position:absolute;right:0;display:none;}", ".navbar-icon.jsx-45394254 .navbar-nav.jsx-45394254 .nav-item.jsx-45394254{margin-right:30px;}", ".navbar-icon.jsx-45394254 .navbar-nav.jsx-45394254 .nav-item.jsx-45394254:nth-child(3){margin-right:78px;}", ".navbar-toggler-icon.jsx-45394254{display:none;}", "@media (max-width:1199px){.navbar.jsx-45394254{width:100%;padding:0;min-width:564px;}.navbar-nav.jsx-45394254{width:100%;}.menu.jsx-45394254 .nav-item.jsx-45394254:active,.menu.jsx-45394254 .nav-item.jsx-45394254:hover{border:none;background:#aaaaaa;}.menu.jsx-45394254 .nav-item.jsx-45394254:active a.jsx-45394254,.menu.jsx-45394254 .nav-item.jsx-45394254:hover a.jsx-45394254{color:#ffffff;}.navbar-brand.jsx-45394254{padding:0 0 0 30px;}.navbar-toggler.jsx-45394254{position:relative;padding-right:48px;margin-right:30px;}.nav-item.jsx-45394254{margin:0;border:none;}.nav-item.jsx-45394254:last-child .nav-link.jsx-45394254{border-bottom:none;}.nav-link.jsx-45394254{padding:7px 0;text-align:center;color:#676767;border-bottom:1px solid #E2E2E2;font-weight:bold;}.active.jsx-45394254 .menu.jsx-45394254 .nav-item.jsx-45394254,.menu.jsx-45394254 .nav-item.jsx-45394254:hover .nav-link.jsx-45394254{color:#ffffff;}.nav-link.jsx-45394254:active{background:#aaaaaa;color:#ffffff;}.navbar-toggle.jsx-45394254{background:none;margin-right:20px;padding:15px 10px 10px;height:70px;}.navbar-toggle.jsx-45394254:focus{outline:none;}.navbar-toggler-icon.jsx-45394254{position:relative;display:inline-block;color:#fff;width:14px;height:16px;cursor:pointer;}.navbar-toggler-icon.jsx-45394254 .bar1.jsx-45394254,.navbar-toggler-icon.jsx-45394254 .bar2.jsx-45394254,.navbar-toggler-icon.jsx-45394254 .bar3.jsx-45394254{display:block;width:14px;height:2px;border-radius:4px;background:#ffffff;-webkit-transition:.3s;transition:.3s;}.navbar-toggler-icon.jsx-45394254 .bar2.jsx-45394254{margin:3px 0;}.navbar-toggle.active.jsx-45394254 .bar1.jsx-45394254{-webkit-transform:rotate(-45deg) translate(-9px,6px);-webkit-transform:rotate(-45deg) translate(-1.5px,4.5px);-ms-transform:rotate(-45deg) translate(-1.5px,4.5px);transform:rotate(-45deg) translate(-1.5px,4.5px);background:#707070;}.navbar-toggle.active.jsx-45394254 .bar2.jsx-45394254{-webkit-transform:rotate(45deg) translate(-8px,-8px);-webkit-transform:rotate(45deg) translate(1px,-2px);-ms-transform:rotate(45deg) translate(1px,-2px);transform:rotate(45deg) translate(1px,-2px);background:#707070;}.navbar-toggle.active.jsx-45394254 .bar3.jsx-45394254{opacity:0;}.navbar-toggler.jsx-45394254:hover,.navbar-toggler.jsx-45394254:focus{outline:none;}.navbar-nav.jsx-45394254{position:relative;z-index:1;top:0;background:#ffffff;box-shadow:0 3px 6px 0 rgba(0,0,0,0.16);border:solid 1px var(--white);padding:10px 0;}.menu.jsx-45394254 .nav-item.active.jsx-45394254,.menu.jsx-45394254 .nav-item.jsx-45394254:hover{border:0;}.navbar-toggler.jsx-45394254{position:relative;padding-right:48px;margin-right:30px;}.nav-item.jsx-45394254{margin:0;}.nav-item.jsx-45394254:last-child .nav-link.jsx-45394254{border-bottom:none;}.nav-link.jsx-45394254{padding:7px 0;text-align:center;color:#676767;border-bottom:1px solid #E2E2E2;font-weight:bold;}.nav-link.jsx-45394254:active{background:#aaaaaa;color:#ffffff;}.navbar-toggle.jsx-45394254:focus{outline:none;}.navbar-toggler-icon.jsx-45394254{position:relative;display:inline-block;color:#fff;width:14px;height:16px;cursor:pointer;}.navbar-toggler-icon.jsx-45394254 .bar1.jsx-45394254,.navbar-toggler-icon.jsx-45394254 .bar2.jsx-45394254,.navbar-toggler-icon.jsx-45394254 .bar3.jsx-45394254{display:block;width:14px;height:2px;border-radius:4px;background:#ffffff;-webkit-transition:.3s;transition:.3s;}.navbar-toggler-icon.jsx-45394254 .bar2.jsx-45394254{margin:3px 0;}.navbar-toggle.active.jsx-45394254 .bar1.jsx-45394254{-webkit-transform:rotate(-45deg) translate(-9px,6px);-webkit-transform:rotate(-45deg) translate(-1.5px,4.5px);-ms-transform:rotate(-45deg) translate(-1.5px,4.5px);transform:rotate(-45deg) translate(-1.5px,4.5px);}.navbar-toggle.active.jsx-45394254 .bar2.jsx-45394254{-webkit-transform:rotate(45deg) translate(-8px,-8px);-webkit-transform:rotate(45deg) translate(1px,-2px);-ms-transform:rotate(45deg) translate(1px,-2px);transform:rotate(45deg) translate(1px,-2px);}.navbar-toggle.active.jsx-45394254 .bar3.jsx-45394254{opacity:0;}.navbar-toggler.jsx-45394254:hover,.navbar-toggler.jsx-45394254:focus{outline:none;}}", "@media (max-width:760px){.navbar.jsx-45394254{padding:0;min-width:320px;}.navbar-brand.jsx-45394254{margin-right:50px;}}"]));
};

/* harmony default export */ var components_Header = (Header);
// CONCATENATED MODULE: ./components/HeaderAdmin.js

var HeaderAdmin_jsx = external_react_default.a.createElement;




 // 관리자 페이지 Header

const HeaderAdmin = props => {
  const router = Object(router_["useRouter"])();
  /**
   * @type {{id: string}[]}
   *
   * post list 에서 연결되어야 하며
   * id 값은 firestore 통해서 넣도록 수정
   */

  const {
    0: menuActive,
    1: setMenuState
  } = Object(external_react_["useState"])(false); //로그아웃

  const logout = async e => {
    e.preventDefault();
    const check = confirm("로그아웃 하시겠습니까?");

    if (check) {
      console.log(`logout check true`);
      const res = await external_isomorphic_unfetch_default()(`http://myxd.co.kr/api/user/logout`);

      if (res.status === 200) {
        console.log('logout success');
        external_js_cookie_default.a.remove('token');
        router.push('/admin/login');
      } else {
        console.log('error occured');
      }
    }
  };

  return HeaderAdmin_jsx("header", {
    className: "jsx-1922450252"
  }, HeaderAdmin_jsx("div", {
    className: "jsx-1922450252" + " " + "nav_wrap"
  }, HeaderAdmin_jsx("nav", {
    className: "jsx-1922450252" + " " + "gnb"
  }, HeaderAdmin_jsx(link_default.a, {
    href: "/"
  }, HeaderAdmin_jsx("a", {
    className: "jsx-1922450252" + " " + "logo"
  }, HeaderAdmin_jsx("span", {
    className: "jsx-1922450252" + " " + "pink"
  }, HeaderAdmin_jsx("img", {
    src: "/img/common/logo.png",
    alt: "myXD",
    style: {
      width: 102 + 'px'
    },
    className: "jsx-1922450252"
  })))), HeaderAdmin_jsx("div", {
    className: "jsx-1922450252" + " " + "menu"
  }, HeaderAdmin_jsx("ul", {
    className: "jsx-1922450252"
  }, HeaderAdmin_jsx("li", {
    className: "jsx-1922450252" + " " + "item"
  }, HeaderAdmin_jsx(link_default.a, {
    href: "/list?cat=uikits"
  }, HeaderAdmin_jsx("a", {
    className: "jsx-1922450252" + " " + "link"
  }, "UI KITS"))), HeaderAdmin_jsx("li", {
    className: "jsx-1922450252" + " " + "item"
  }, HeaderAdmin_jsx(link_default.a, {
    href: "/list?cat=website"
  }, HeaderAdmin_jsx("a", {
    className: "jsx-1922450252" + " " + "link"
  }, "Website"))), HeaderAdmin_jsx("li", {
    className: "jsx-1922450252" + " " + "item"
  }, HeaderAdmin_jsx(link_default.a, {
    href: "/list?cat=mobile"
  }, HeaderAdmin_jsx("a", {
    className: "jsx-1922450252" + " " + "link"
  }, "Mobile"))), HeaderAdmin_jsx("li", {
    className: "jsx-1922450252" + " " + "item"
  }, HeaderAdmin_jsx(link_default.a, {
    href: "/list?cat=plugin"
  }, HeaderAdmin_jsx("a", {
    className: "jsx-1922450252" + " " + "link"
  }, "Plug-in"))))), HeaderAdmin_jsx("div", {
    className: "jsx-1922450252" + " " + "icon-menu"
  }, HeaderAdmin_jsx("ul", {
    className: "jsx-1922450252"
  }, HeaderAdmin_jsx("li", {
    className: "jsx-1922450252" + " " + "item"
  }, HeaderAdmin_jsx(link_default.a, {
    href: "/admin/logout"
  }, HeaderAdmin_jsx("a", {
    onClick: logout,
    href: "#",
    className: "jsx-1922450252" + " " + "link"
  }, HeaderAdmin_jsx("img", {
    src: "/img/common/login.png",
    alt: "login",
    className: "jsx-1922450252"
  })))))))), HeaderAdmin_jsx(style_default.a, {
    id: "1922450252"
  }, ["header.jsx-1922450252{width:100%;height:70px;background:#2e001f;}", ".nav_wrap.jsx-1922450252{width:1200px;background:#2e001f;height:70px;margin:0 auto;}", ".nav_wrap.jsx-1922450252 .gnb.jsx-1922450252{width:1160px;height:70px;margin:0 auto;padding:0 30px;color:#fff;}", ".nav_wrap.jsx-1922450252 .logo.jsx-1922450252{font-size:20px;line-height:66px;margin-right:95px;float:left;}", ".nav_wrap.jsx-1922450252 .menu.jsx-1922450252{position:relative;margin:0 auto;width:-webkit-fit-content;width:-moz-fit-content;width:fit-content;}", ".nav_wrap.jsx-1922450252 .menu.jsx-1922450252 ul.jsx-1922450252 .item.jsx-1922450252{float:left;margin-right:80px;line-height:68px;}", ".nav_wrap.jsx-1922450252 .menu.jsx-1922450252 ul.jsx-1922450252 .item.active.jsx-1922450252 .link.jsx-1922450252,.nav_wrap.jsx-1922450252 .menu.jsx-1922450252 ul.jsx-1922450252 .item.jsx-1922450252:hover .link.jsx-1922450252{border-bottom:2px solid var(--pink);border-bottom:2px solid #e83e8c;color:var(--pink);color:#e83e8c;}", ".nav_wrap.jsx-1922450252 .menu.jsx-1922450252 ul.jsx-1922450252 .item.jsx-1922450252 .item.jsx-1922450252:last-child{margin-right:0 !important;}", ".nav_wrap.jsx-1922450252 .menu.jsx-1922450252 ul.jsx-1922450252 .item.jsx-1922450252 .link.jsx-1922450252{padding:8.5px 10px !important;font-weight:bold;color:#fff;}", ".nav_wrap.jsx-1922450252 .icon-menu.jsx-1922450252{position:relative;}", ".nav_wrap.jsx-1922450252 .icon-menu.jsx-1922450252 ul.jsx-1922450252 .item.jsx-1922450252{position:absolute;right:0;line-height:62px;}", ".nav_wrap.jsx-1922450252 .icon-menu.jsx-1922450252 ul.jsx-1922450252 .item.jsx-1922450252 .link.jsx-1922450252{padding:10px;color:#ffffff;}", ".nav_wrap.jsx-1922450252 .icon-menu.jsx-1922450252 ul.jsx-1922450252 .item.jsx-1922450252:nth-child(3){margin-right:78px;}"]));
};

/* harmony default export */ var components_HeaderAdmin = (HeaderAdmin);
// CONCATENATED MODULE: ./components/Footer.js


var Footer_jsx = external_react_default.a.createElement;

// Footer
const Footer = props => Footer_jsx("footer", {
  className: "jsx-3594961345"
}, Footer_jsx("div", {
  className: "jsx-3594961345" + " " + ((props.isResponsive ? "footer" : "footer footer-xl") || "")
}, Footer_jsx("div", {
  className: "jsx-3594961345"
}, "Copyright \xA9 Domfam Corp. All rights reserved.")), Footer_jsx(style_default.a, {
  id: "3594961345"
}, [".footer.jsx-3594961345{width:100%;height:60px;border:solid 1px #707070;background-color:#777777;}", ".footer.jsx-3594961345 div.jsx-3594961345{width:1200px;margin:0 auto;padding-left:30px;font-size:12px;color:#FFF;vertical-align:middle;line-height:60px;}", "@media (max-width:1200px){.footer.jsx-3594961345 div.jsx-3594961345{width:100%;padding-left:30px;}.footer-xl.jsx-3594961345{min-width:1200px;}}", "@media (max-width:768px){.footer.jsx-3594961345 div.jsx-3594961345{padding-left:20px;}.footer-xl.jsx-3594961345{min-width:1200px;}}"]));

/* harmony default export */ var components_Footer = (Footer);
// CONCATENATED MODULE: ./components/Layout.js
var Layout_jsx = external_react_default.a.createElement;







const Layout = props => {
  const {
    page,
    activeMenu
  } = props; // 관리자 페이지 접속인지 확인

  const router = Object(router_["useRouter"])();
  const path = router.pathname.split('/'); // 페이지에 따른 반응형 처리

  const isAdmin = path[1] === 'admin';
  let isAdminLogin = false;

  if (isAdmin) {
    isAdminLogin = path[2] === 'login' || path[2] === '';
  }

  const isResponsive = isAdmin && !isAdminLogin ? false : true;
  let containerClass = '';
  containerClass = page === 'list' ? 'list-container' : '';
  containerClass += isResponsive ? " container" : " container-xl";
  return Layout_jsx(external_react_default.a.Fragment, null, Layout_jsx(head_default.a, null, Layout_jsx("title", null, "Adobe XD \uBB34\uB8CC \uD15C\uD50C\uB9BF\uC744 \uB9CC\uB098\uBCF4\uC138\uC694 - My XD"), Layout_jsx("meta", {
    name: "viewport",
    content: "initial-scale=1.0, width=device-width",
    key: "viewport"
  }), Layout_jsx("meta", {
    name: "Referrer",
    content: "origin"
  }), Layout_jsx("meta", {
    httpEquiv: "X-UA-Compatible",
    content: "IE=Edge"
  }), Layout_jsx("meta", {
    name: "viewport",
    content: "width=device-width, initial-scale=1.0"
  }), Layout_jsx("meta", {
    name: "robots",
    content: "index,follow"
  }), Layout_jsx("meta", {
    property: "og:type",
    content: "website"
  }), Layout_jsx("meta", {
    property: "og:image",
    content: "/img/common/logo_og.png"
  }), Layout_jsx("meta", {
    property: "og:url",
    content: "http://myxd.co.kr/"
  }), Layout_jsx("link", {
    rel: "shortcut icon",
    type: "image/x-icon",
    href: "/favicon.ico"
  }), Layout_jsx("link", {
    rel: "apple-touch-icon",
    sizes: "180x180",
    href: "/img/common/apple-icon-180x180.png"
  }), Layout_jsx("link", {
    rel: "icon",
    type: "image/png",
    sizes: "192x192",
    href: "/img/common/android-icon-192x192.png"
  }), Layout_jsx("meta", {
    name: "msapplication-TileColor",
    content: "#ffffff"
  }), Layout_jsx("meta", {
    name: "msapplication-TileImage",
    content: "/img/common/ms-icon-144x144.png"
  }), Layout_jsx("meta", {
    name: "theme-color",
    content: "#ffffff"
  }), Layout_jsx("script", {
    src: "/js/jquery.js"
  }), Layout_jsx("script", {
    src: "/js/bootstrap.min.js"
  }), Layout_jsx("script", {
    src: "/js/common.js"
  })), isAdmin ? Layout_jsx(components_HeaderAdmin, null) : Layout_jsx(components_Header, {
    isResponsive: isResponsive,
    activeMenu: activeMenu
  }), Layout_jsx("div", {
    className: containerClass
  }, props.children), Layout_jsx(components_Footer, {
    isResponsive: isResponsive && !isAdminLogin
  }));
};

/* harmony default export */ var components_Layout = __webpack_exports__["a"] = (Layout);

/***/ }),

/***/ "G4HQ":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("lhFH");

/***/ }),

/***/ "HJQg":
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "P5f7":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

function rewriteUrlForNextExport(url) {
  const [pathname, hash] = url.split('#'); // tslint:disable-next-line

  let [path, qs] = pathname.split('?');

  if (path) {
    path = path.replace(/\/$/, ''); // Append a trailing slash if this path does not have an extension

    if (!/\.[^/]+\/?$/.test(path)) path += `/`;
  }

  if (qs) path += '?' + qs;
  if (hash) path += '#' + hash;
  return path;
}

exports.rewriteUrlForNextExport = rewriteUrlForNextExport;

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "YTqd":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

function getRouteRegex(normalizedRoute) {
  // Escape all characters that could be considered RegEx
  const escapedRoute = (normalizedRoute.replace(/\/$/, '') || '/').replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = escapedRoute.replace(/\/\\\[([^/]+?)\\\](?=\/|$)/g, (_, $1) => {
    const isCatchAll = /^(\\\.){3}/.test($1);
    groups[$1 // Un-escape key
    .replace(/\\([|\\{}()[\]^$+*?.-])/g, '$1').replace(/^\.{3}/, '') // eslint-disable-next-line no-sequences
    ] = {
      pos: groupIndex++,
      repeat: isCatchAll
    };
    return isCatchAll ? '/(.+?)' : '/([^/]+?)';
  });
  return {
    re: new RegExp('^' + parameterizedRoute + '(?:/)?$', 'i'),
    groups
  };
}

exports.getRouteRegex = getRouteRegex;

/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("KI45");

var _interopRequireWildcard = __webpack_require__("5Uuq");

exports.__esModule = true;
exports.default = void 0;

var _url = __webpack_require__("bzos");

var _react = _interopRequireWildcard(__webpack_require__("cDcd"));

var _router = _interopRequireDefault(__webpack_require__("nOHt"));

var _utils = __webpack_require__("g/15");

function isLocal(href) {
  var url = (0, _url.parse)(href, false, true);
  var origin = (0, _url.parse)((0, _utils.getLocationOrigin)(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return (href, as) => {
    if (lastResult && href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? (0, _utils.formatWithValidation)(url) : url;
}

var observer;
var listeners = new Map();
var IntersectionObserver = false ? undefined : null;
var prefetched = {};

function getObserver() {
  // Return shared instance of IntersectionObserver if already created
  if (observer) {
    return observer;
  } // Only create shared IntersectionObserver if supported in browser


  if (!IntersectionObserver) {
    return undefined;
  }

  return observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!listeners.has(entry.target)) {
        return;
      }

      var cb = listeners.get(entry.target);

      if (entry.isIntersecting || entry.intersectionRatio > 0) {
        observer.unobserve(entry.target);
        listeners.delete(entry.target);
        cb();
      }
    });
  }, {
    rootMargin: '200px'
  });
}

var listenToIntersections = (el, cb) => {
  var observer = getObserver();

  if (!observer) {
    return () => {};
  }

  observer.observe(el);
  listeners.set(el, cb);
  return () => {
    try {
      observer.unobserve(el);
    } catch (err) {
      console.error(err);
    }

    listeners.delete(el);
  };
};

class Link extends _react.Component {
  constructor(props) {
    super(props);
    this.p = void 0;

    this.cleanUpListeners = () => {};

    this.formatUrls = memoizedFormatUrl((href, asHref) => {
      return {
        href: formatUrl(href),
        as: asHref ? formatUrl(asHref) : asHref
      };
    });

    this.linkClicked = e => {
      // @ts-ignore target exists on currentTarget
      var {
        nodeName,
        target
      } = e.currentTarget;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var {
        href,
        as
      } = this.formatUrls(this.props.href, this.props.as);

      if (!isLocal(href)) {
        // ignore click if it's outside our scope (e.g. https://google.com)
        return;
      }

      var {
        pathname
      } = window.location;
      href = (0, _url.resolve)(pathname, href);
      as = as ? (0, _url.resolve)(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var {
        scroll
      } = this.props;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      _router.default[this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: this.props.shallow
      }).then(success => {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      });
    };

    if (false) {}

    this.p = props.prefetch !== false;
  }

  componentWillUnmount() {
    this.cleanUpListeners();
  }

  getHref() {
    var {
      pathname
    } = window.location;
    var {
      href: parsedHref
    } = this.formatUrls(this.props.href, this.props.as);
    return (0, _url.resolve)(pathname, parsedHref);
  }

  handleRef(ref) {
    var isPrefetched = prefetched[this.getHref()];

    if (this.p && IntersectionObserver && ref && ref.tagName) {
      this.cleanUpListeners();

      if (!isPrefetched) {
        this.cleanUpListeners = listenToIntersections(ref, () => {
          this.prefetch();
        });
      }
    }
  } // The function is memoized so that no extra lifecycles are needed
  // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html


  prefetch() {
    if (!this.p || true) return; // Prefetch the JSON page if asked (only in the client)

    var href = this.getHref();

    _router.default.prefetch(href);

    prefetched[href] = true;
  }

  render() {
    var {
      children
    } = this.props;
    var {
      href,
      as
    } = this.formatUrls(this.props.href, this.props.as); // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

    if (typeof children === 'string') {
      children = _react.default.createElement("a", null, children);
    } // This will return the first child, if multiple are provided it will throw an error


    var child = _react.Children.only(children);

    var props = {
      ref: el => {
        this.handleRef(el);

        if (child && typeof child === 'object' && child.ref) {
          if (typeof child.ref === 'function') child.ref(el);else if (typeof child.ref === 'object') {
            child.ref.current = el;
          }
        }
      },
      onMouseEnter: e => {
        if (child.props && typeof child.props.onMouseEnter === 'function') {
          child.props.onMouseEnter(e);
        }

        this.prefetch();
      },
      onClick: e => {
        if (child.props && typeof child.props.onClick === 'function') {
          child.props.onClick(e);
        }

        if (!e.defaultPrevented) {
          this.linkClicked(e);
        }
      }
    }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
    // defined, we specify the current 'href', so that repetition is not needed by the user

    if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
      props.href = as || href;
    } // Add the ending slash to the paths. So, we can serve the
    // "<page>/index.html" directly.


    if (true) {
      var rewriteUrlForNextExport = __webpack_require__("P5f7").rewriteUrlForNextExport;

      if (props.href && typeof __NEXT_DATA__ !== 'undefined' && __NEXT_DATA__.nextExport) {
        props.href = rewriteUrlForNextExport(props.href);
      }
    }

    return _react.default.cloneElement(child, props);
  }

}

if (false) { var exact, PropTypes, warn; }

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "dZ6Y":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
MIT License

Copyright (c) Jason Miller (https://jasonformat.com/)

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

Object.defineProperty(exports, "__esModule", {
  value: true
});

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        // tslint:disable-next-line:no-bitwise
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

exports.default = mitt;

/***/ }),

/***/ "elyg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

const url_1 = __webpack_require__("bzos");

const mitt_1 = __importDefault(__webpack_require__("dZ6Y"));

const utils_1 = __webpack_require__("g/15");

const is_dynamic_1 = __webpack_require__("/jkW");

const route_matcher_1 = __webpack_require__("gguc");

const route_regex_1 = __webpack_require__("YTqd");

function addBasePath(path) {
  // @ts-ignore variable is always a string
  const p = "";
  return path.indexOf(p) !== 0 ? p + path : path;
}

function toRoute(path) {
  return path.replace(/\/$/, '') || '/';
}

class Router {
  constructor(pathname, query, as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    err,
    subscription
  }) {
    // Static Data Cache
    this.sdc = {};

    this.onPopState = e => {
      if (!e.state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', utils_1.formatWithValidation({
          pathname,
          query
        }), utils_1.getURL());
        return;
      } // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site


      if (e.state && this.isSsr && e.state.url === this.pathname && e.state.as === this.asPath) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(e.state)) {
        return;
      }

      const {
        url,
        as,
        options
      } = e.state;

      if (false) {}

      this.replace(url, as, options);
    };

    this._getStaticData = (asPath, _cachedData) => {
      let pathname = url_1.parse(asPath).pathname;
      pathname = toRoute(!pathname || pathname === '/' ? '/index' : pathname);
      return  true && (_cachedData = this.sdc[pathname]) ? Promise.resolve(_cachedData) : fetch( // @ts-ignore __NEXT_DATA__
      `/_next/data/${__NEXT_DATA__.buildId}${pathname}.json`).then(res => {
        if (!res.ok) {
          throw new Error(`Failed to load static props`);
        }

        return res.json();
      }).then(data => {
        this.sdc[pathname] = data;
        return data;
      }).catch(err => {
        ;
        err.code = 'PAGE_LOAD_ERROR';
        throw err;
      });
    }; // represents the current component key


    this.route = toRoute(pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        props: initialProps,
        err
      };
    }

    this.components['/_app'] = {
      Component: App
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented
    // @ts-ignore backwards compatibility

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = pathname;
    this.query = query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    this.asPath = // @ts-ignore this is temporarily global (attached to window)
    is_dynamic_1.isDynamicRoute(pathname) && __NEXT_DATA__.autoExport ? pathname : as;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;

    if (false) {}
  } // @deprecated backwards compatibility even though it's a private method.


  static _rewriteUrlForNextExport(url) {
    if (true) {
      const rewriteUrlForNextExport = __webpack_require__("P5f7").rewriteUrlForNextExport;

      return rewriteUrlForNextExport(url);
    } else {}
  }

  update(route, mod) {
    const Component = mod.default || mod;
    const data = this.components[route];

    if (!data) {
      throw new Error(`Cannot update unavailable route: ${route}`);
    }

    const newData = Object.assign(Object.assign({}, data), {
      Component
    });
    this.components[route] = newData; // pages/_app.js updated

    if (route === '/_app') {
      this.notify(this.components[this.route]);
      return;
    }

    if (route === this.route) {
      this.notify(newData);
    }
  }

  reload() {
    window.location.reload();
  }
  /**
   * Go back in history
   */


  back() {
    window.history.back();
  }
  /**
   * Performs a `pushState` with arguments
   * @param url of the route
   * @param as masks `url` for the browser
   * @param options object you can define `shallow` and other options
   */


  push(url, as = url, options = {}) {
    return this.change('pushState', url, as, options);
  }
  /**
   * Performs a `replaceState` with arguments
   * @param url of the route
   * @param as masks `url` for the browser
   * @param options object you can define `shallow` and other options
   */


  replace(url, as = url, options = {}) {
    return this.change('replaceState', url, as, options);
  }

  change(method, _url, _as, options) {
    return new Promise((resolve, reject) => {
      if (!options._h) {
        this.isSsr = false;
      } // marking route changes as a navigation start entry


      if (utils_1.ST) {
        performance.mark('routeChange');
      } // If url and as provided as an object representation,
      // we'll format them into the string version here.


      const url = typeof _url === 'object' ? utils_1.formatWithValidation(_url) : _url;
      let as = typeof _as === 'object' ? utils_1.formatWithValidation(_as) : _as; // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly for the SSR page.

      if (true) {
        const rewriteUrlForNextExport = __webpack_require__("P5f7").rewriteUrlForNextExport; // @ts-ignore this is temporarily global (attached to window)


        if (__NEXT_DATA__.nextExport) {
          as = rewriteUrlForNextExport(as);
        }
      }

      this.abortComponentLoad(as); // If the url change is only related to a hash change
      // We should not proceed. We should only change the state.
      // WARNING: `_h` is an internal option for handing Next.js client-side
      // hydration. Your app should _never_ use this property. It may change at
      // any time without notice.

      if (!options._h && this.onlyAHashChange(as)) {
        this.asPath = as;
        Router.events.emit('hashChangeStart', as);
        this.changeState(method, url, addBasePath(as), options);
        this.scrollToHash(as);
        Router.events.emit('hashChangeComplete', as);
        return resolve(true);
      }

      const {
        pathname,
        query,
        protocol
      } = url_1.parse(url, true);

      if (!pathname || protocol) {
        if (false) {}

        return resolve(false);
      } // If asked to change the current URL we should reload the current page
      // (not location.reload() but reload getInitialProps and other Next.js stuffs)
      // We also need to set the method = replaceState always
      // as this should not go into the history (That's how browsers work)
      // We should compare the new asPath to the current asPath, not the url


      if (!this.urlIsNew(as)) {
        method = 'replaceState';
      } // @ts-ignore pathname is always a string


      const route = toRoute(pathname);
      const {
        shallow = false
      } = options;

      if (is_dynamic_1.isDynamicRoute(route)) {
        const {
          pathname: asPathname
        } = url_1.parse(as);
        const routeRegex = route_regex_1.getRouteRegex(route);
        const routeMatch = route_matcher_1.getRouteMatcher(routeRegex)(asPathname);

        if (!routeMatch) {
          const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

          if (missingParams.length > 0) {
            if (false) {}

            return reject(new Error(`The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). ` + `Read more: https://err.sh/zeit/next.js/incompatible-href-as`));
          }
        } else {
          // Merge params into `query`, overwriting any specified in search
          Object.assign(query, routeMatch);
        }
      }

      Router.events.emit('routeChangeStart', as); // If shallow is true and the route exists in the router cache we reuse the previous result
      // @ts-ignore pathname is always a string

      this.getRouteInfo(route, pathname, query, as, shallow).then(routeInfo => {
        const {
          error
        } = routeInfo;

        if (error && error.cancelled) {
          return resolve(false);
        }

        Router.events.emit('beforeHistoryChange', as);
        this.changeState(method, url, addBasePath(as), options);
        const hash = window.location.hash.substring(1);

        if (false) {} // @ts-ignore pathname is always defined


        this.set(route, pathname, query, as, Object.assign(Object.assign({}, routeInfo), {
          hash
        }));

        if (error) {
          Router.events.emit('routeChangeError', error, as);
          throw error;
        }

        Router.events.emit('routeChangeComplete', as);
        return resolve(true);
      }, reject);
    });
  }

  changeState(method, url, as, options = {}) {
    if (false) {}

    if (method !== 'pushState' || utils_1.getURL() !== as) {
      // @ts-ignore method should always exist on history
      window.history[method]({
        url,
        as,
        options
      }, null, as);
    }
  }

  getRouteInfo(route, pathname, query, as, shallow = false) {
    const cachedRouteInfo = this.components[route]; // If there is a shallow route transition possible
    // If the route is already rendered on the screen.

    if (shallow && cachedRouteInfo && this.route === route) {
      return Promise.resolve(cachedRouteInfo);
    }

    return new Promise((resolve, reject) => {
      if (cachedRouteInfo) {
        return resolve(cachedRouteInfo);
      }

      this.fetchComponent(route).then(Component => resolve({
        Component
      }), reject);
    }).then(routeInfo => {
      const {
        Component
      } = routeInfo;

      if (false) {}

      return this._getData(() => Component.__N_SSG ? this._getStaticData(as) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      })).then(props => {
        routeInfo.props = props;
        this.components[route] = routeInfo;
        return routeInfo;
      });
    }).catch(err => {
      return new Promise(resolve => {
        if (err.code === 'PAGE_LOAD_ERROR') {
          // If we can't load the page it could be one of following reasons
          //  1. Page doesn't exists
          //  2. Page does exist in a different zone
          //  3. Internal error while loading the page
          // So, doing a hard reload is the proper way to deal with this.
          window.location.href = as; // Changing the URL doesn't block executing the current code path.
          // So, we need to mark it as a cancelled error and stop the routing logic.

          err.cancelled = true; // @ts-ignore TODO: fix the control flow here

          return resolve({
            error: err
          });
        }

        if (err.cancelled) {
          // @ts-ignore TODO: fix the control flow here
          return resolve({
            error: err
          });
        }

        resolve(this.fetchComponent('/_error').then(Component => {
          const routeInfo = {
            Component,
            err
          };
          return new Promise(resolve => {
            this.getInitialProps(Component, {
              err,
              pathname,
              query
            }).then(props => {
              routeInfo.props = props;
              routeInfo.error = err;
              resolve(routeInfo);
            }, gipErr => {
              console.error('Error in error page `getInitialProps`: ', gipErr);
              routeInfo.error = err;
              routeInfo.props = {};
              resolve(routeInfo);
            });
          });
        }));
      });
    });
  }

  set(route, pathname, query, as, data) {
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    this.notify(data);
  }
  /**
   * Callback to execute before replacing router state
   * @param cb callback to be executed
   */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value

    if (hash === '') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
   * Prefetch `page` code, you may wait for the data during `page` rendering.
   * This feature only works in production!
   * @param url of prefetched `page`
   */


  prefetch(url) {
    return new Promise((resolve, reject) => {
      const {
        pathname,
        protocol
      } = url_1.parse(url);

      if (!pathname || protocol) {
        if (false) {}

        return;
      } // Prefetch is not supported in development mode because it would trigger on-demand-entries


      if (false) {} // @ts-ignore pathname is always defined


      const route = toRoute(pathname);
      this.pageLoader.prefetch(route).then(resolve, reject);
    });
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const Component = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return Component;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return utils_1.loadGetInitialProps(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as) {
    if (this.clc) {
      const e = new Error('Route Cancelled');
      e.cancelled = true;
      Router.events.emit('routeChangeError', e, as);
      this.clc();
      this.clc = null;
    }
  }

  notify(data) {
    this.sub(data, this.components['/_app'].Component);
  }

}

exports.default = Router;
Router.events = mitt_1.default();

/***/ }),

/***/ "g/15":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

const url_1 = __webpack_require__("bzos");
/**
 * Utils
 */


function execOnce(fn) {
  let used = false;
  let result = null;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn.apply(this, args);
    }

    return result;
  };
}

exports.execOnce = execOnce;

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

exports.getLocationOrigin = getLocationOrigin;

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

exports.getURL = getURL;

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

exports.getDisplayName = getDisplayName;

function isResSent(res) {
  return res.finished || res.headersSent;
}

exports.isResSent = isResSent;

async function loadGetInitialProps(App, ctx) {
  var _a;

  if (false) {} // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (false) {}

  return props;
}

exports.loadGetInitialProps = loadGetInitialProps;
exports.urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];

function formatWithValidation(url, options) {
  if (false) {}

  return url_1.format(url, options);
}

exports.formatWithValidation = formatWithValidation;
exports.SP = typeof performance !== 'undefined';
exports.ST = exports.SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "gguc":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = decodeURIComponent;
    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

exports.getRouteMatcher = getRouteMatcher;

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "iZP3":
/***/ (function(module, exports, __webpack_require__) {

var _Symbol$iterator = __webpack_require__("XVgq");

var _Symbol = __webpack_require__("Z7t5");

function _typeof2(obj) { if (typeof _Symbol === "function" && typeof _Symbol$iterator === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _Symbol === "function" && _typeof2(_Symbol$iterator) === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "lhFH":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/weak-map");

/***/ }),

/***/ "nOHt":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("5Uuq");

var _interopRequireDefault = __webpack_require__("KI45");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router2 = _interopRequireWildcard(__webpack_require__("elyg"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__("qOIg");

var _withRouter = _interopRequireDefault(__webpack_require__("0Bsm"));

exports.withRouter = _withRouter.default;
/* global window */

var singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

var urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components'];
var routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
var coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      var router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = function () {
    var router = getRouter();
    return router[field](...arguments);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, function () {
      var eventField = "on" + event.charAt(0).toUpperCase() + event.substring(1);
      var _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...arguments);
        } catch (err) {
          // tslint:disable-next-line:no-console
          console.error("Error when running the Router event: " + eventField); // tslint:disable-next-line:no-console

          console.error(err.message + "\n" + err.stack);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    var message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


var createRouter = function createRouter() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  var _router = router;
  var instance = {};

  for (var property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign({}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = function () {
      return _router[field](...arguments);
    };
  });
  return instance;
}

/***/ }),

/***/ "qOIg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var __importStar = this && this.__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  result["default"] = mod;
  return result;
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

const React = __importStar(__webpack_require__("cDcd"));

exports.RouterContext = React.createContext(null);

/***/ }),

/***/ "qyRQ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("HJQg");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("5Yp1");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("3i/4");
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_cookies__WEBPACK_IMPORTED_MODULE_6__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;







const PlayList = props => {
  const {
    idx,
    link,
    onChange
  } = props;

  const playListChange = e => {
    onChange(e.target.value, idx);
  };

  return __jsx(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, __jsx("input", {
    type: "text",
    name: "playList",
    value: link,
    placeholder: "https://www.youtube.com/watch?v=Ljw1Hcn15C",
    maxLength: "250",
    onChange: playListChange,
    className: "jsx-2709639309" + " " + "form-control"
  }), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "2709639309"
  }, ["input.jsx-2709639309{margin-bottom:10px;}"]));
};

const New = props => {
  // 입력값
  const {
    0: title,
    1: setTitle
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: hash,
    1: setHash
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: playList,
    1: setPlayList
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(["", "", ""]);
  const {
    0: content,
    1: setContent
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: link,
    1: setLink
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_4__["useRouter"])(); // 제목 입력

  const titleChange = e => {
    setTitle(e.target.value);
  }; // 제목 입력


  const hashChange = e => {
    setHash(e.target.value);
  }; // 내용 입력


  const contentChange = e => {
    setContent(e.target.value);
  }; // 링크 입력


  const linkChange = e => {
    setLink(e.target.value);
  }; // 플레이리스트 입력창 추가


  const addPlayList = e => {
    e.preventDefault();
    setPlayList(playList => [...playList, ""]);
  }; // 플레이리스트 입력


  const handlePlayListChange = (val, idx) => {
    setPlayList(playList.map((item, i) => idx === i ? val : item));
  }; // 취소 클릭


  const cancelSubmit = e => {
    e.preventDefault();
    const check = confirm("작성을 취소하시겠습니까?");

    if (check) {
      router.push("/admin/lecture");
    }
  }; // 저장


  const handleSubmit = async e => {
    e.preventDefault();
    /**
     *  data check here
     */

    if (!title || !hash || !content || !link) {
      alert("값을 모두 입력해주세요.");
      return;
    }

    const check = confirm("등록하시겠습니까?");

    if (check) {
      const reqData = {
        title,
        hash: hash.split(","),
        content,
        link
      }; // db insert data
      // playList 있는 경우에만 추가

      const play = playList.filter(item => item !== "");
      if (play.length) reqData.playList = play;
      axios__WEBPACK_IMPORTED_MODULE_5___default.a.post(`${"http://myxd.co.kr"}/api/lecture/create`, reqData, {
        headers: {
          Accept: "application/json",
          Headers: "content-type",
          "Content-Type": "application/json"
        }
      }).then(() => {
        alert("업로드 되었습니다.");
        router.push("/admin/lecture");
      }).catch(err => {
        console.log(err);
        alert("uncaught error occured");
        router.push("/admin/lecture");
      });
    }
  };

  return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], null, __jsx(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, null, __jsx("title", {
    className: "jsx-2026163832"
  }, "Admin - New")), __jsx("div", {
    className: "jsx-2026163832" + " " + "content"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "row box"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "col col-sm-12"
  }, __jsx("h1", {
    className: "jsx-2026163832" + " " + "header"
  }, "\uAC15\uC758 \uAE00\uC4F0\uAE30"), __jsx("div", {
    className: "jsx-2026163832" + " " + "row"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "col col-sm-12"
  }, __jsx("form", {
    encType: "multipart/form-data",
    onSubmit: handleSubmit,
    className: "jsx-2026163832"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "form-group"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "label-area"
  }, __jsx("label", {
    htmlFor: "title",
    className: "jsx-2026163832" + " " + "col-form-label"
  }, "\uC81C\uBAA9 *")), __jsx("div", {
    className: "jsx-2026163832" + " " + "input-area"
  }, __jsx("input", {
    id: "title",
    type: "text",
    name: "title",
    placeholder: "제목을 입력해 주세요",
    onChange: titleChange,
    className: "jsx-2026163832" + " " + "form-control"
  }))), __jsx("div", {
    className: "jsx-2026163832" + " " + "form-group"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "label-area"
  }, __jsx("label", {
    htmlFor: "hash",
    className: "jsx-2026163832" + " " + "col-form-label"
  }, "\uD0DC\uADF8\uB2EC\uAE30 *")), __jsx("div", {
    className: "jsx-2026163832" + " " + "input-area"
  }, __jsx("input", {
    id: "hash",
    type: "text",
    name: "hash",
    placeholder: "태그를 ','로 입력해 주세요",
    onChange: hashChange,
    className: "jsx-2026163832" + " " + "form-control"
  }))), __jsx("div", {
    className: "jsx-2026163832" + " " + "form-group"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "label-area"
  }, __jsx("label", {
    style: {
      lineHeight: "20.4"
    },
    htmlFor: "description",
    className: "jsx-2026163832" + " " + "col-form-label"
  }, "\uB0B4\uC6A9 *")), __jsx("div", {
    className: "jsx-2026163832" + " " + "input-area"
  }, __jsx("textarea", {
    id: "description",
    name: "content",
    placeholder: "내용을 입력해 주세요",
    maxLength: "1000",
    onChange: contentChange,
    className: "jsx-2026163832" + " " + "form-control"
  }))), __jsx("div", {
    className: "jsx-2026163832" + " " + "form-group"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "label-area"
  }, __jsx("label", {
    htmlFor: "link",
    className: "jsx-2026163832" + " " + "col-form-label"
  }, "\uC720\uD29C\uBE0C \uB9C1\uD06C *")), __jsx("div", {
    className: "jsx-2026163832" + " " + "input-area"
  }, __jsx("input", {
    id: "link",
    type: "text",
    name: "link",
    placeholder: "https://www.youtube.com/watch?v=Ljw1Hcn15C",
    maxLength: "250",
    onChange: linkChange,
    className: "jsx-2026163832" + " " + "form-control"
  }))), __jsx("div", {
    className: "jsx-2026163832" + " " + "form-group"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "label-area"
  }, __jsx("label", {
    className: "jsx-2026163832" + " " + "col-form-label"
  }, "\uD50C\uB808\uC774 \uB9AC\uC2A4\uD2B8")), __jsx("div", {
    className: "jsx-2026163832" + " " + "input-area"
  }, playList.map((item, idx) => __jsx(PlayList, {
    key: idx,
    idx: idx,
    link: item,
    onChange: handlePlayListChange
  })), __jsx("button", {
    onClick: addPlayList,
    className: "jsx-2026163832" + " " + "btn-sm btn-gray-7"
  }, "+ \uCD94\uAC00"))), __jsx("div", {
    className: "jsx-2026163832" + " " + "row form-btn"
  }, __jsx("div", {
    className: "jsx-2026163832" + " " + "col col-sm-12 text-center"
  }, __jsx("button", {
    href: "#",
    onClick: cancelSubmit,
    className: "jsx-2026163832" + " " + "btn btn-lg btn-outline-lightgray"
  }, "\uCDE8\uC18C"), __jsx("button", {
    href: "#",
    type: "submit",
    className: "jsx-2026163832" + " " + "btn btn-lg btn-primary ml-3"
  }, "\uC800\uC7A5"))))))))), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "2026163832"
  }, [".box.jsx-2026163832{margin:70px auto;border:0 solid transparent;box-shadow:0 3px 6px 0 rgba(0,0,0,0.16);background-color:#fff;}", ".header.jsx-2026163832{margin:33px 35px 0;padding:0 0 34px;font-weight:bold;line-height:1;border-bottom:3px solid #96959a;}", "form.jsx-2026163832{margin:0 35px;}", ".form-group.jsx-2026163832{position:relative;}", ".label-area.jsx-2026163832{position:absolute;width:17%;top:20px;left:0;padding-left:10px;font-size:18px;}", ".input-area.jsx-2026163832{width:83%;margin-left:17%;padding-right:10px;}", ".detail-input-area.jsx-2026163832{display:inline-block;width:calc(27.6% - 1px);margin-left:0;}", ".detail-img-group.jsx-2026163832{width:auto;display:inline-block;margin-left:10px;}", "textarea.jsx-2026163832{height:381px;line-height:30px;resize:none;}", ".form-btn.jsx-2026163832{margin:40px auto;}"]));
};

New.getInitialProps = async ctx => {
  const {
    token
  } = next_cookies__WEBPACK_IMPORTED_MODULE_6___default()(ctx);
  const auth = !!token; // if (!auth) {
  //   ctx.res.writeHead(302, { Location: "/admin/login" });
  //   ctx.res.end();
  // }

  return {
    auth: auth
  };
};

/* harmony default export */ __webpack_exports__["default"] = (New);

/***/ }),

/***/ "vmXh":
/***/ (function(module, exports) {

module.exports = require("js-cookie");

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ })

/******/ });