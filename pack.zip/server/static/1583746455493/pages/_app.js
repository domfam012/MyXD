module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("1TCz");


/***/ }),

/***/ "1TCz":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./public/css/bootstrap.css
var bootstrap = __webpack_require__("sCXG");

// EXTERNAL MODULE: external "@fortawesome/fontawesome-svg-core"
var fontawesome_svg_core_ = __webpack_require__("sLJp");

// EXTERNAL MODULE: ./node_modules/@fortawesome/fontawesome-svg-core/styles.css
var styles = __webpack_require__("VAPu");

// EXTERNAL MODULE: ./public/css/style.css
var style = __webpack_require__("znoa");

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: ./config.js
var config = __webpack_require__("obyI");

// CONCATENATED MODULE: ./public/js/gtag.js
// GA tag
 // https://developers.google.com/analytics/devguides/collection/gtagjs/pages

const pageview = url => {
  window.gtag('config', config["option"].GA_TRACKING_ID, {
    page_path: url
  });
}; // https://developers.google.com/analytics/devguides/collection/gtagjs/events

const gtag_event = ({
  action,
  category,
  label,
  value
}) => {
  window.gtag('event', action, {
    event_category: category,
    event_label: label,
    value: value
  });
};
// CONCATENATED MODULE: ./pages/_app.js
var __jsx = external_react_default.a.createElement;



 // Import the CSS

fontawesome_svg_core_["config"].autoAddCss = false; // Tell Font Awesome to skip adding the CSS automatically since it's being imported above
// 전역 css


/* ga(google analytics) 연동 */



router_default.a.events.on("routeChangeComplete", url => pageview(url));

function MyApp({
  Component,
  pageProps
}) {
  return __jsx(Component, pageProps);
}

/* harmony default export */ var _app = __webpack_exports__["default"] = (MyApp);

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "VAPu":
/***/ (function(module, exports) {



/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "obyI":
/***/ (function(module, exports) {

// live: {
//     apiKey: "AIzaSyBDq0nTd2Czqy9XtOOOdjaWEcWwdmPV_Fw",
//     authDomain: "myxd-live.firebaseapp.com",
//     databaseURL: "https://myxd-live.firebaseio.com",
//     projectId: "myxd-live",
//     storageBucket: "myxd-live.appspot.com",
//     messagingSenderId: "967461744534",
//     appId: "1:967461744534:web:89ae4ed5d1d505a9dab7b7"
// }
// stage: {
//     apiKey: "AIzaSyC_5Ia408Xj6EJ6aKbLzlOS_RHssy3R9uY",
//     authDomain: "myxd-stage.firebaseapp.com",
//     databaseURL: "https://myxd-stage.firebaseio.com",
//     projectId: "myxd-stage",
//     storageBucket: "myxd-stage.appspot.com",
//     messagingSenderId: "864151577963",
//     appId: "1:864151577963:web:185d4aaa421f8cb917982e"
// }
const option = {
  firestore: {
    apiKey: "AIzaSyDyYie0HBPkZslWwib3DNBCIXM9VBMtL3s",
    authDomain: "myxd-247f4.firebaseapp.com",
    databaseURL: "https://myxd-247f4.firebaseio.com",
    projectId: "myxd-247f4",
    storageBucket: "myxd-247f4.appspot.com",
    messagingSenderId: "575641093519",
    appId: "1:575641093519:web:56035054fbaa244dfe37fa"
  },
  assetPrefix: {
    dev: "http://localhost:3000",
    aws: "http://myxd.co.kr",
    ghp: "https://pyungwook-domfam.github.io/domfam012"
  },
  ip: {
    dev: "127.0.0.1",
    production: "13.209.55.219"
  },
  port: {
    dev: 3000,
    production: 80
  },
  GA_TRACKING_ID: "UA-158587547-1"
};
module.exports = {
  option
};

/***/ }),

/***/ "sCXG":
/***/ (function(module, exports) {



/***/ }),

/***/ "sLJp":
/***/ (function(module, exports) {

module.exports = require("@fortawesome/fontawesome-svg-core");

/***/ }),

/***/ "znoa":
/***/ (function(module, exports) {



/***/ })

/******/ });